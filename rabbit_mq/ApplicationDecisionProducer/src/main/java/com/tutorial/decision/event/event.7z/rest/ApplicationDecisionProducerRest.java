package com.mgic.decision.event.rest;

import java.math.BigDecimal;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mgic.decision.event.model.LoanDto;
import com.mgic.decision.event.producer.LoanDecisionEventPublisher;

@RestController
@RequestMapping("/app/decision")
public class ApplicationDecisionProducerRest {

	private Logger LOGGER = LogManager.getLogger(ApplicationDecisionProducerRest.class);

	@Autowired
	private LoanDecisionEventPublisher decisionEventPublisher;

	@GetMapping("/health")
	private String healthCheck() {
		return "Up and Running...!";
	}

	@PostMapping(path = "/trigger/{loanId}")
	private String triggerEvent(@PathVariable String loanId) {
		LoanDto dto = new LoanDto();

		dto.setDTI(new BigDecimal("0.45"));
		dto.setFICO(780);
		dto.setLoanAmt(450000L);
		dto.setProductType("MGIC_LOAN1_PRODUCT");
		dto.setPropertyType("SINGLE_HOME_DETACHED");
		LOGGER.info("Publishing event : {}", dto);
		
		decisionEventPublisher.publishEvent(dto);

		return "Triggered Loan decision event.";
	}

}
